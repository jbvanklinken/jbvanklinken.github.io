%%

clc
clear


% generate random stoichiometric matrix
n=[10 20];
S=[diag(floor(rand(n(1),1)*3)+1),round(0.7*randn(n(1),n(2)-n(1)))];
A=1;
while rank(A)<n(1)
    A=round(randn(n(1)*1.5,n(1))*0.3);
end;
S=A*S;
rev=rand(1,n(2))>0.6;


% show help of both functions
help calculate_flux_modes
help bin2num_flux_modes


% calculate binary EFMs
[efm_bin,S_unc,id_unc,T,stats]=calculate_flux_modes(S,rev);

% calculate coefficients of binary EFMs and check for consistency
[efm,err]=bin2num_flux_modes(efm_bin,S);

