function [i1,i2,dt2,err]=align_time_sequences(t1,t2)
% ALIGN_TIME_SEQUENCES Aligns two monotonically increasing sequences
%
%  [i1,i2,dt2,err] = ALIGN_TIME_SEQUENCES(t1,t2) aligns the time sequences
%  t1 and t2, returning the sets of indices i1 and i2 such that t1(i1) is
%  equal to t2(i2). The sequence t2 must increase at a constant rate. In
%  addition, the sample time of t2 is returned, and an error flag that
%  indicates whether: the sample time of t2 is not constant (err=1), t1
%  and/or t2 are not monotonically increasing (err=2), or no error occurred
%  (err=0).


err=0;
dt2=mean(diff(t2));
a=abs(t2(:)/dt2-t2(1)/dt2-[0:(length(t2)-1)]');
if max(a)>=1
    err=1;      % t2 does not increase at a constant rate
end;
if [min(diff(t1))<=0]|[min(diff(t2))<=0]
    err=2;      % t1 or t2 do not increase monotonically
end;
i2=round((t1-t2(1))/dt2+1);
i1=find([1<=i2]&[length(t2)>=i2]);
i2=i2(i1);


