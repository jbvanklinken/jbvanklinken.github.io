The current directory contains the files of the MATLAB toolbox for calculating the time-dependent resting metabolic rate and activity related energy expenditure from indirect calorimetry data. 
(c) 2012 Jan Bert van Klinken


The toolbox and its functions should be cited as:

Van Klinken JB, van den Berg SAA, Havekes LM, Willems Van Dijk K (2012)
Estimation of Activity Related Energy Expenditure and Resting Metabolic
Rate in Freely Moving Mice from Indirect Calorimetry Data. PLoS ONE 7(5):
e36162

The toolbox is distributed under the terms of the Creative Commons
Attribution License, in accordance with PLoS ONE policy on sharing data
and materials. See http://creativecommons.org/licenses/by/2.5/ for details.




The script file "test_TEE_decomposition.m" shows how to use the energy expenditure decomposition toolbox for MATLAB, by analysing a dataset from an indirect calorimetry experiment that was performed on mice. Please note that this analysis requires that the optimisation toolbox from MATLAB is installed.