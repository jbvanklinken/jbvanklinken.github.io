function [b,a]=calculate_discrete_time_filter_coefficients(tau,T)
% [b,a] = CALCULATE_DISCRETE_TIME_FILTER_COEFFICIENTS(tau,T) calculates the
% IIR filter coefficients b and a that pertain to a sequence of linear
% compartments with washout times tau, assuming a sample time T. The
% continuous-time to discrete-time transform is based on the impulse
% invariance technique.
%
% [tau1] = CALCULATE_DISCRETE_TIME_FILTER_COEFFICIENTS(tau,T) gives the 
% adjusted washout times tau1 that follow from the impulse invariance
% transform.

if isempty(tau)
    tau=0;
end;
tau1=1./(1-exp(-T./tau));
if nargout==2
    b=1./prod(tau1,2);
    tau2=1./tau1-1;
    a=[1,tau2(1)];
    for i=2:length(tau2)
        a=conv(a,[1,tau2(i)]);
    end;
elseif nargout==1
    b=tau1;
end;
    