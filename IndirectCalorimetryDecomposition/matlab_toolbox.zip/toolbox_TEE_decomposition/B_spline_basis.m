function [B_out,dB_out]=B_spline_basis(t_in,knots,n_degree)
% [B]=B_SPLINE_BASIS(t,k,n) calculates the B-spline basis functions B of
% degree n, at time instances t, with knots at locations k. In the case k
% is a scalar, its value indicates the number of knots which are chosen at
% equidistant locations.
%
% [B,dB]=B_SPLINE_BASIS(t,k,n) also outputs the first order derivative dB
% of the spline basis functions B.


[t,j]=sort(t_in);
[i,j]=sort(j);
t=reshape(t,length(t_in),1);
if nargin<3
    % cubic spline is default
    n_degree=3;
end;

if length(knots)==1
    n_knots=knots;
    t_knots=[0:n_knots]/n_knots*(t(end)-t(1))+t(1);
else
    t_knots=knots;
end;
t_knots=[t_knots(1)*ones(1,n_degree),t_knots,t_knots(end)*ones(1,n_degree)];
    
n_knots=length(t_knots);



if 1==1
    % fast implementation of the de Boor algorithm that exploits sparse matrices
    ii=t*0;
    for i=1:(n_knots-1)
        ii=ii+[t>=t_knots(i)];
    end;
    i=find(ii>0);
    B=sparse(i,ii(i),1,length(t),n_knots-1);
    B1=[];
    B2=[];
    B3=[];
    
    A7=sparse(1:length(t),1:length(t),t);
    for m=1:n_degree
        A5=sparse([1:(n_knots-m-1),2:(n_knots-m)],[1:(n_knots-m-1),1:(n_knots-m-1)],1./[t_knots((m+1):(n_knots-1))-t_knots(1:(n_knots-m-1)),t_knots(2:(n_knots-m))-t_knots((m+2):n_knots)]);
        A6=sparse([1:(n_knots-m-1),2:(n_knots-m)],[1:(n_knots-m-1),1:(n_knots-m-1)],1./[[t_knots((m+1):(n_knots-1))./t_knots(1:(n_knots-m-1)),t_knots(2:(n_knots-m))./t_knots((m+2):n_knots)]-1]);
    
        A5(isnan(A5))=0;
        A5(isinf(A5))=0;
        A6(isnan(A6))=0;
        A6(isinf(A6))=0;
        B3=B2;
        B2=B1;
        B1=B;
        B=A7*[B*A5]-B*A6; 
    end;
end;
if t_knots(end)==max(t_in)
    B(end,end)=1;
end;
B_out=B(j,:);

if nargout>1
    if ~isempty(B1)
        B1(end,size(B1,2)-1)=1;
        B1(end,end)=0;
        m=n_degree;
        tt=t_knots(1:(n_knots-m))-t_knots((m+1):n_knots);
        B1=sparse(m*diff(diag(1./tt)*B1')');
        dB_out=B1(j,:);
    else
        dB_out=[];
    end;
end;



