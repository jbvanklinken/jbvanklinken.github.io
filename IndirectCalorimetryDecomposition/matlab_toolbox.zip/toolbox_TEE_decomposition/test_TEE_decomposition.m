% The current script file shows how to use the energy expenditure
% decomposition toolbox for MATLAB, by analysing a dataset from an indirect
% calorimetry experiment that was performed on mice. Please note that this
% analysis requires that the optimisation toolbox from MATLAB is installed.
%
% This script file is part of the MATLAB toolbox for calculating the
% time-dependent resting metabolic rate and activity related energy
% expenditure from indirect calorimetry data. (c) 2012 Jan Bert van Klinken
% The toolbox and its functions should be cited as:
%
% Van Klinken JB, van den Berg SAA, Havekes LM, Willems Van Dijk K (2012)
% Estimation of Activity Related Energy Expenditure and Resting Metabolic
% Rate in Freely Moving Mice from Indirect Calorimetry Data. PLoS ONE 7(5):
% e36162
%
% The toolbox is distributed under the terms of the Creative Commons
% Attribution License, in accordance with PLoS ONE policy on sharing data
% and materials. See http://creativecommons.org/licenses/by/2.5/ for details.




%% INITIALISATION

clc
clear

% Set values of global parameters:
% - the absolute temperature T
T=21+273.15;

% - the number of knots per day in the spline function that is used for
%   fitting the activity preprocessing function
knots_per_day_preprocessing=10;

% - the number of knots per day in the spline function that is used for
%   TEE decomposion
knots_per_day=15;



% Load case-study data (indirect calorimetry experiment performed on mice).
% The structure "MC_data" contains the time sequences of the total energy
% expenditure ("TEE"), the TEE sample times ("time"), the airflow through
% the system ("flow"), the infrared beam activity data in X and Z
% direction ("activity_X/Ztot_highres"), the activity sample times
% ("time_activity"), the body weight ("BW"), and the gender ("class").
load([pwd,'\data\casestudy_data_TEE_decomposition.mat'])



% Calculate the total activity in X and Z direction, expressed in infrared
% beam interruptions per minute.
for i=1:length(MC_data)
    MC_data(i).activity=[MC_data(i).activity_Xtot_highres+MC_data(i).activity_Ztot_highres]/mean(diff(MC_data(1).time_activity))/24/60;
end;




%% PARAMETER FITTING AND ACTIVITY PREPROCESSING
% Before decomposing the total energy expenditure into an activity and
% resting component, the activity and energy expenditure time sequences
% need to be aligned and the activity data needs to preprocessed in order
% to ascertain a linear relationship between the measured activity data
% and the related energy expenditure.


% First the activity and EE data are aligned. The function
% align_time_sequences returns the sets of indices i_TEE and i_PA such that
% TEE(i_TEE) is aligned with activity(i_PA). 
for i=1:length(MC_data)
    [i_TEE,i_PA,dt,err]=align_time_sequences(MC_data(i).time,MC_data(i).time_activity);
    if err==1
        disp(['Warning: the activity data of dataset ',num2str(i),' has been sampled with a varying sample time . . .'])
    elseif err==2
        error(['Sample times of TEE or activity data of dataset ',num2str(i),' are not monotonically increasing . . .'])
    end;
    
    MC_data(i).i_activity=[i_TEE,i_PA];
    MC_data(i).dt_activity=dt*24*3600;
end;


% The parameters of the preprocessing function for the activity data are
% stored in a structure (here "param"), which contains all information
% needed by the preprocess_activity_data function to transform the
% activity data. The parameter structure is required as input for the
% function preprocess_activity_data, and the meaning of each field in
% "param" is declared within this function. Therefore, additional
% parameters or transformations can be included by altering the function
% preprocess_activity_data.

% First the parameter structure is declared and initial values are assigned.
for i=1:length(MC_data)
    param(i)=struct('KernelType','Gaussian','KernelParam',26,'DeltaT',5,'Threshold',8,'Exponent',0.2,'Tau1',1.5,'Tau2',MC_data(i).chamber_volume/mean(MC_data(i).flow*T/273.15)*60);
end;


% Subsequently, the preprocessing parameters are fitted to the data. The
% function fit_activity_preprocessing_parameters takes as input the
% sequences (in cell format) of the TEE, activity and activity indices. In
% addition the array of activity sample times is given, the number of knots
% per day, the initial parameter values, and a cell with the parameter
% names whose values need to be optimised; the remaining parameter fields
% are not optimised and maintain their initial values.
param=fit_activity_preprocessing_parameters({MC_data.TEE},{MC_data.activity},{MC_data.i_activity},cell2mat({MC_data.dt_activity}),knots_per_day_preprocessing,param,{'Exponent','Threshold'});


% Finally the activity data is preprocessed with the fitted parameter
% values; the result is stored in MC_data.
for i=1:length(MC_data)
    MC_data(i).activity_preprocessed=zeros(length(MC_data(i).TEE),1)*NaN;
    j=MC_data(i).i_activity(:,1);
    MC_data(i).activity_preprocessed(j)=preprocess_activity_data(MC_data(i).activity,MC_data(i).i_activity(:,2),MC_data(i).dt_activity,param(i));
end;





%% ENERGY EXPENDITURE DECOMPOSITION
% Once the activity data has been preprocessed and aligned with the energy
% expenditure data, the TEE can be decomposed into the RMR and AEE. The
% function TEE_decomposition_Psplines takes as input the TEE sequence, the
% (preprocessed) activity, and the time instants at which TEE has been
% sampled (expressed in days). In addition, parameter values can be given
% for the knot number, the range of the smoothing parameter, and the range
% of the relative measurement error in the activity. As output it yields
% estimates of the time dependent RMR and AEE, the caloric cost of
% activity, the activity measurement error, and the optimal smoothing
% parameter. See the TEE_decomposition_Psplines function for details.

for i=1:length(MC_data)
    knotnumber=round(knots_per_day*(MC_data(i).time(end)-MC_data(i).time(1)));
    [RMR,AEE,CCA]=TEE_decomposition_Psplines(MC_data(i).TEE,MC_data(i).activity_preprocessed,MC_data(i).time,'KnotNumber',knotnumber);
    
    % Store the results in the MC_data structure
    MC_data(i).RMR=RMR;
    MC_data(i).AEE=AEE;
    MC_data(i).CCA=CCA;
end;





%% VISUALISATION OF RESULTS

i=1;


% Visualisation of the time sequence of TEE, RMR and AEE of dataset i
figure(1)
plot(MC_data(i).time,[MC_data(i).TEE,MC_data(i).RMR,MC_data(i).AEE])
set(gca,'YLim',[0 20])
box off
xlabel('time [days]')
ylabel('EE [kcal/hr]')
legend({'TEE','RMR','AEE'})
legend boxoff



a=ceil(max(MC_data(i).AEE));

% Scatterplot of the residuals of the P-splines model fit against the AEE.
% From this scatterplot it can be determined whether the preprocessing
% function of the activity data worked correctly, or whether nonlinear
% trends remain in the residuals. 
figure(2)
subplot(1,2,1)
plot(MC_data(i).AEE,MC_data(i).TEE-MC_data(i).RMR,'.')
hold on
plot([0,a],[0,a],'r','LineWidth',2)
hold off
box off
xlabel('AEE')
ylabel('TEE-RMR')
subplot(1,2,2)
plot(MC_data(i).AEE,MC_data(i).TEE-MC_data(i).RMR-MC_data(i).AEE,'.')
hold on
plot([0,a]',[0,0],'r','LineWidth',2)
hold off
box off
xlabel('AEE')
ylabel('residuals')


