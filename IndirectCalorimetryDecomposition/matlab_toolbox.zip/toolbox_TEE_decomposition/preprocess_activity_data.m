function [PA_out]=preprocess_activity_data(PA_in,i_PA,dt_PA,param_in)
% PREPROCESS_ACTIVITY_DATA preprocesses raw activity data and aligns in
% with the energy expenditure data. 
%
%   PA = PREPROCESS_ACTIVITY_DATA(PA_raw,i_PA,dt,param) preprocesses the
%   raw activity data PA_raw. Required input arguments are the indices i_PA
%   that align the activity data with the energy expenditure data, the sample
%   time dt of the activity data expressed in seconds, and the parameters
%   of the preprocessing function. PA_raw may contain multiple activity
%   sequences as columns. In contrast, PA is always a single column vector.
%
%   param_out = PREPROCESS_ACTIVITY_DATA(param) imposes standard
%   constraints on the parameter values and returns the result.
%
%   The preprocessing parameters are stored in a structure, which has the
%   following fields
%     KernelType - Type of kernel function. Possible values are 'none' and 
%     'Gaussian'
%     KernelParam - Specific parameters of the kernel function. For the
%     Gaussian kernel KernelParam is a scalar denoting the kernel width.
%     DeltaT - The time shift with respect to the TEE, expressed in
%     seconds. A positive value implies a delay in the activity data.
%     Threshold - Threshold value below which activity intensity is put to
%     zero. In the case PA_raw has multiple columns, Threshold may be a row
%     vector containing a separate value for each column in PA_raw.
%     Exponent - Power that is taken of the activity data. In the case
%     PA_raw has multiple columns, Exponent may be a row vector containing
%     a separate value for each column in PA_raw.
%     LinearCoeff - Row vector containing the linear coefficients
%     associated with the columns in PA_raw. The size of LinearCoeff is the
%     number of columns in PA_raw minus one, since the last coefficient is
%     deduced from the former ones assuming they all add up to one.
%     Tau1 - Washout time of the body of the subject expressed in seconds.
%     Tau2 - Washout time of the calorimeter expressed in seconds. This
%     value should be zero if deconvolution has been performed on the
%     energy expenditure sequence.
%
%
% The current function is part of the MATLAB toolbox for calculating the
% time-dependent resting metabolic rate and activity related energy
% expenditure from indirect calorimetry data. (c) 2012 Jan Bert van Klinken
% The toolbox and its functions should be cited as:
%
% Van Klinken JB, van den Berg SAA, Havekes LM, Willems Van Dijk K (2012)
% Estimation of Activity Related Energy Expenditure and Resting Metabolic
% Rate in Freely Moving Mice from Indirect Calorimetry Data. PLoS ONE 7(5):
% e36162
%
% The toolbox is distributed under the terms of the Creative Commons
% Attribution License, in accordance with PLoS ONE policy on sharing data
% and materials. See http://creativecommons.org/licenses/by/2.5/ for details.



if nargin==1
    param_in=PA_in;
end;

% Enforce constraints on the parameter values
if isfield(param_in,'KernelParam')
    param_in.KernelParam=abs(param_in.KernelParam);
end;
if isfield(param_in,'Threshold')
    param_in.Threshold=abs(param_in.Threshold);
end;
if isfield(param_in,'Exponent')
    param_in.Exponent=min(abs(param_in.Exponent),3);
end;
if isfield(param_in,'Tau1')
    param_in.Tau1=abs(param_in.Tau1);
end;
if isfield(param_in,'Tau2')
    param_in.Tau2=abs(param_in.Tau2);
end;



if nargin>=3
    [n,m]=size(PA_in);
    
    kerneltypes={'none','Gaussian'};

    % Define the types of parameters and assign default values
    param=struct('KernelType','none','KernelParam',[],'DeltaT',0,'Threshold',0,'Exponent',1,'Tau1',0,'Tau2',0,'LinearCoeff',ones(1,m-1)/m,'Maximum',Inf);

    % Import input parameters
    param_fieldnames=fieldnames(param_in);
    for i=1:length(param_fieldnames)
        if isfield(param,param_fieldnames{i})
            param.(param_fieldnames{i})=param_in.(param_fieldnames{i});
        else
            error([param_fieldnames{i},' is not a valid preprocessing parameter . . .']);
        end;
    end;
    
    % Calculate the full array of linear coefficients 
    a=param.LinearCoeff;
    a=[a(:);1-sum(a)];
    
    % Determine the time shift expressed in sample times
    dt=param.DeltaT/dt_PA;
    dt=[floor(dt),dt-floor(dt)];

    % Calculate the time sequence c of the kernel function 
    i_kernel=find(strcmp(param.KernelType,kerneltypes));
    if i_kernel==1
        c=[1-dt(2);dt(2)];
    elseif i_kernel==2
        s=param.KernelParam(1)/dt_PA;
        s1=max(ceil(4*s+dt(2)));
        t=[[-s1:s1]'-dt(2)]/s;
        c=exp(-t.*t/2);
        c=c./sum(c,1);
        dt(1)=dt(1)-s1;
    else
        error([param.KernelType,' is an unknown kerneltype . . .']);
    end;


    % Rename the raw activity data as x
    x=PA_in;

    % Convolve x with the kernel function, taking into account positive
    % time shifts
    z1=zeros(max(-dt(1),0),m);
    z2=zeros(max(dt(1),0),m);
    x=[z2;x;z1];
    x=conv2(c,x);

    % Apply the threshold, exponential and linear coefficients to x
    a1=ones(1,(length(param.Threshold)~=m)*(m-1)+1)*param.Threshold;
    a2=ones(1,(length(param.Exponent)~=m)*(m-1)+1)*param.Exponent;
    a3=ones(1,(length(param.Maximum)~=m)*(m-1)+1)*param.Maximum;
    x=[max(min(x,a3(ones(size(x,1),1),:))-a1(ones(size(x,1),1),:),0).^a2(ones(size(x,1),1),:)]*a;
    
    % Apply the filtering effect induced by the linear compartments 
    [b_filter,a_filter]=calculate_discrete_time_filter_coefficients([param.Tau1,param.Tau2],dt_PA);
    x=filter(b_filter,a_filter,x);
    
    % Remove first entries of x in the case the time shift is negative
    i_shift=[z1(:,1);ones(n,1)]==1;
    x=x(i_shift);
    
    % Downsample the activity sequence 
    PA_out=x(i_PA);
    
    
elseif nargin==1
    PA_out=param_in;
else
    PA_out=[];
end;

