function [param_out]=fit_activity_preprocessing_parameters(IC_in,PA_in,i_PA_in,dt_PA,knots_per_day,param_in,param_names_fit,minimal_sample_time,i_filter_in)
% FIT_ACTIVITY_PREPROCESSING_PARAMETERS fits the set of parameters that are
% used in the preprocessing function PREPROCESS_ACTIVITY_DATA
%
%   p=FIT_ACTIVITY_PREPROCESSING_PARAMETERS(IC,PA,i_PA,dt,k,p0,p_fit)
%   returns the optimal values of the activity preprocessing parameters p,
%   based on the goodness of fit of the predicted time-dependent indirect
%   calorimetry data to the actual data. The input arguments are: the
%   measured time sequence of indirect calorimetry data IC, the measured time
%   sequence of physical activity PA, and the indices i_PA that align PA
%   with IC. IC, PA and i_PA can be vectors, or, in the case that the fit
%   of the parameter values needs to be based on multiple datasets, IC, PA
%   and i_PA can be cells containing vectors. Additional input arguments
%   are the sample time dt with which PA has been measured, the number of
%   knots k in the spline function that models the time-dependent RMR, the
%   initial values of the parameters p0, and a cell p_fit containing the
%   names of the parameter fields whose values need to be optimised. Note
%   that the remaining parameter fields, i.e. those not mentioned in p_fit,
%   will maintain the value declared in p0. In the case of multiple
%   datasets the size of p0 must be equal to the cell size of IC, PA and
%   i_PA.   
%
%
% The current function is part of the MATLAB toolbox for calculating the
% time-dependent resting metabolic rate and activity related energy
% expenditure from indirect calorimetry data. (c) 2012 Jan Bert van Klinken
% The toolbox and its functions should be cited as:
%
% Van Klinken JB, van den Berg SAA, Havekes LM, Willems Van Dijk K (2012)
% Estimation of Activity Related Energy Expenditure and Resting Metabolic
% Rate in Freely Moving Mice from Indirect Calorimetry Data. PLoS ONE 7(5):
% e36162
%
% The toolbox is distributed under the terms of the Creative Commons
% Attribution License, in accordance with PLoS ONE policy on sharing data
% and materials. See http://creativecommons.org/licenses/by/2.5/ for details.



if nargin<8
    minimal_sample_time=dt_PA;
end;
if nargin<9
    i_filter_in=[];
end;
if length(minimal_sample_time)==1
    minimal_sample_time=ones(length(dt_PA),1)*minimal_sample_time;
end;


% In the case that only a single IC and PA sequence is given, they are put
% in cell format.
if ~iscell(IC_in)
    IC_in={IC_in};
    PA_in={PA_in};
    i_PA_in={i_PA_in};
    if ~isempty(i_filter_in)
        i_filter_in={i_filter_in};
    end;
end;
n_datasets=length(IC_in);


% Remove missing values in IC (NaN's). Missing values are not allowed in
% the PA sequence.
for i=1:n_datasets
    IC_in{i}=IC_in{i}(i_PA_in{i}(:,1));
    i_PA_in{i}=i_PA_in{i}(:,2);
    
    j=isnan(IC_in{i});
    IC_in{i}(j)=[];
    i_PA_in{i}(j)=[];
    if sum(isnan(PA_in{i}))>0
        error(['Physical activity sequence ',num2str(i),' contains NaN''s . . .'])
    end;
    
    downsampling_factor=max(minimal_sample_time(i)/dt_PA(i),1);
    if downsampling_factor>1
        n=size(PA_in{i},1);
        i1=round([((downsampling_factor-1)/2+1):downsampling_factor:n])';
        
        i_PA_in{i}=round((i_PA_in{i}-1)/downsampling_factor)+1;
        i1=[i1;ones(i_PA_in{i}(end)-length(i1),1)*i1(end)];
        I1=diff([0;i1]);
        I1=I1+[I1==0];
        x=cumsum(PA_in{i});
        PA_in{i}=diff([zeros(1,size(x,2));x(i1,:)])./I1(:,ones(1,size(x,2)));

        if mean(diff(find(diff(i_PA_in{i})~=0)))>2
            I=sparse(i_PA_in{i},1:length(i_PA_in{i}),1);
            IC_in{i}=full(I*IC_in{i})./[full(sum(I,2))*ones(1,size(IC_in{i},2))];
            i_PA_in{i}=[1:max(i_PA_in{i})]';
            if ~isempty(i_filter_in)
                i_filter_in{i}=(full(I*i_filter_in{i})./(full(sum(I,2))*ones(1,size(i_filter_in{i},2))))>0.5;
            end;
        end;
    end;
end;


% Construct a single vector containing all IC time sequences, and
% construct a single matrix Z with the spline basis functions for each
% dataset.
Z=[];
IC=[];
i_filter=[];
a=[0,0];
for i_dataset=1:n_datasets
    i_PA=i_PA_in{i_dataset};
    [i,j,v]=find(B_spline_basis(i_PA,round(knots_per_day*(i_PA(end)-i_PA(1))*dt_PA(i_dataset)/24/3600),3));
    Z=[Z;[i+a(1),j+a(2),v]];
    a=a+[max(i),max(j)];    
    IC=[IC;IC_in{i_dataset}];
    if ~isempty(i_filter_in)
        i_filter=[i_filter;i_filter_in{i_dataset}];
    end;
end;
if isempty(i_filter_in)
    i_filter=IC*0;
end;
i_filter=i_filter==1;
Z=sparse(Z(:,1),Z(:,2),Z(:,3));
Z(i_filter,:)=0;
z=full(sum(Z,1));
Z(:,z./max(z)<1e-6)=[];
IC(i_filter,1)=0;
ZZ=Z'*Z;
alpha=IC-full(Z*[ZZ\full(Z'*IC)]);

% Convert the parameter structure into an single array x with the parameter
% values that can be optimised.
[x,param_i_fit,param_fixed]=extract_param(param_in,param_names_fit);

% Find the optimal value for the parameter array x.
x=fminsearch(@(xx)ll(xx,IC,PA_in,i_PA_in,dt_PA,Z,ZZ,alpha,param_i_fit,param_names_fit,param_fixed,i_filter),x);

% Reconvert the parameter array x into a parameter structure.
p=merge_param(x,param_i_fit,param_names_fit,param_fixed); 

% Apply constraints on the parameters that are imposed by the
% preprocess_activity_data function.
param_out=preprocess_activity_data(p(1));
for i=2:length(p)
    param_out(i)=preprocess_activity_data(p(i));
end;
param_out=orderfields(param_out,param_in);






% --------------------------
% --------------------------
function e2=ll(param,IC,PA,i_PA,dt_PA,Z,ZZ,alpha,param_i_fit,param_names_fit,param_fixed,i_filter)
% Residual sum of squares function, given the parameters param. This
% function is minimised in order to find the optimal value for param.


preprocessing_param=merge_param(param,param_i_fit,param_names_fit,param_fixed);
x=[];
for i=1:length(PA)
    x1=preprocess_activity_data(PA{i},i_PA{i},dt_PA(i),preprocessing_param(i));
    x=[x;x1];
end;
x(i_filter,1)=0;
Zx=full(Z'*x);
e2=[IC'*alpha-(x'*alpha)*(x'*alpha)/(x'*x-Zx'*(ZZ\Zx))]/(size(Z,1)-size(Z,2));






% --------------------------
% --------------------------
function param_merged=merge_param(x,param_i_fit,param_names_fit,param_fixed)
% Convert parameter array into a structure

param_merged=param_fixed;
n=length(param_fixed);
for i=1:length(param_names_fit)
    for j=1:n
        param_merged(j).(param_names_fit{i})=x(param_i_fit(j,:)==i);
    end;
end





% --------------------------
% --------------------------
function [x,param_i_fit,param_fixed]=extract_param(param_in,param_names_fit)
% Transfer the parameter values present in the structure param_in that need to be
% optimised into the array x

n=length(param_in);
param_fixed=rmfield(param_in,param_names_fit);

param_i_fit=[];
x=[];

for j=1:length(param_names_fit)
    if 1==1
        x1=param_in(1).(param_names_fit{j});
        param_i_fit(1:n,length(x)+[1:length(x1)])=j;
        x=[x,x1];
    else
        for i=1:n
            x1=param_in(i).(param_names_fit{j});
            param_i_fit(i,length(x)+[1:length(x1)])=j;
            x=[x,x1];
        end;
    end;
end;








